#pragma once
#include "Geometry.h"

class mPolygon : public Geometry{
public:
	mPolygon(int id, double* bound, std::vector<int>& parts, std::vector<PointXY*>& points)
		: Geometry(id, bound, parts, points)
	{}
	GeoType getType() const { return GeoType::POLYGON; }
	// ��д���ຯ��
	double getLength() const { return 0.0; }; // ��ʱ�����ʵ��
	double getArea() const { return 0.0; };
};

