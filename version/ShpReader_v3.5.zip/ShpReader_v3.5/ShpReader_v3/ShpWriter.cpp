#include "ShpWriter.h"
#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdint>
constexpr int FILE_CODE = 9994;
constexpr int VERSION = 1000;
constexpr double DEFAULT = 0.0f;

// ����ͼ��
void ShpWriter::ParseLayer(Layer* layer) {
	std::ofstream shpFile(msFileName, std::ios::binary);
	if (!shpFile) {
		std::cerr << "Error opening file for writing." << std::endl;
		return;
	}
	// д���ļ�ͷ
	int nLayerType = WriteHeader(shpFile, layer);
	// д���¼
	WriteRecords(shpFile, layer, nLayerType);
}
// д���ļ�ͷ
int ShpWriter::WriteHeader(std::ofstream& shpFile, Layer* layer) {
	char header[100] = { 0 };

	// File Code (9994, Big Endian)
	uint32_t fileCode = toBigEndian(9994);
	std::memcpy(header, &fileCode, sizeof(fileCode));

	// Unused fields (0, Big Endian)
	for (int i = 4; i <= 20; i += 4) {
		uint32_t unused = 0;
		unused = toBigEndian(unused);
		std::memcpy(header + i, &unused, sizeof(unused));
	}

	// File Length (Big Endian)
	int fileLength = layer->getFileLength();
	uint32_t length = toBigEndian(fileLength);
	std::memcpy(header + 24, &length, sizeof(length));

	// Version (1000, Little Endian)
	uint32_t version = VERSION;;
	std::memcpy(header + 28, &version, sizeof(version));

	// Shape Type (Little Endian)
	uint32_t type = static_cast<uint32_t>(layer->getType());
	std::memcpy(header + 32, &type, sizeof(type));

	// Bounding Box (Xmin, Ymin, Xmax, Ymax, Little Endian)
	const double* bounds = layer->getBoundingBox();
	double lxmin = bounds[0];
	double lymin = bounds[1];
	double lxmax = bounds[2];
	double lymax = bounds[3];
	std::memcpy(header + 36, &lxmin, sizeof(lxmin));
	std::memcpy(header + 44, &lymin, sizeof(lymin));
	std::memcpy(header + 52, &lxmax, sizeof(lxmax));
	std::memcpy(header + 60, &lymax, sizeof(lymax));

	// Bounding Box Zmin and Zmax (Little Endian)
	double lzmin = DEFAULT;
	double lzmax = DEFAULT;
	std::memcpy(header + 68, &lzmin, sizeof(lzmin));
	std::memcpy(header + 76, &lzmax, sizeof(lzmax));

	// Bounding Box Mmin and Mmax (Little Endian)
	double lmmin = DEFAULT;
	double lmmax = DEFAULT;
	std::memcpy(header + 84, &lmmin, sizeof(lmmin));
	std::memcpy(header + 92, &lmmax, sizeof(lmmax));
	// Write the header to file
	shpFile.write(header, 100);
	return type;
}
// д���¼
void ShpWriter::WriteRecords(std::ofstream& shpFile, Layer* layer, int nLayerType) {
	GeoType layerType = static_cast<GeoType>(nLayerType);
	switch (layerType) {
	case GeoType::POINT: 
		WritePoint(shpFile, layer);
		break;
	case GeoType::POLYLINE: 
		WritePoly(shpFile, layer);
		break;
	case GeoType::POLYGON: 
		WritePoly(shpFile, layer);
		break;
	}
}
// д�������
void ShpWriter::WritePoint(std::ofstream& shpFile, Layer* layer) {
	int nRecordNumber = 1; // ��¼����
	for (Geometry* geom : layer->getFeatures()) {
		// д���¼ͷ
		int recordLength = 2 * (geom->getPointSize() * 2 + 3); // �����ݳ��ȣ�ÿ���� 2 �ֽ����� + �����ֽڣ�
		recordLength = toBigEndian(recordLength);
		int nRno = toBigEndian(nRecordNumber);
		shpFile.write(reinterpret_cast<char*>(&nRno), sizeof(int));
		shpFile.write(reinterpret_cast<char*>(&recordLength), sizeof(int));

		// д�뼸������
		int shapeType = static_cast<int>(geom->getType());
		shpFile.write(reinterpret_cast<char*>(&shapeType), sizeof(int));

		// ����������
		mPoint* pt = dynamic_cast<mPoint*>(geom);
		double x = pt->getX();
		double y = pt->getY();
		shpFile.write(reinterpret_cast<char*>(&x), sizeof(double));
		shpFile.write(reinterpret_cast<char*>(&y), sizeof(double));
		nRecordNumber++;
	}
}
// д����������
void ShpWriter::WritePoly(std::ofstream& shpFile, Layer* layer) {
	int nRecordNumber = 1;	//��¼����
	for (Geometry* geom : layer->getFeatures()) {
		// д���¼ͷ
		int recordLength = 2 * (geom->getPointSize() * 2 + 3); // �����ݳ��ȣ�ÿ���� 2 �ֽ����� + �����ֽڣ�
		recordLength = toBigEndian(recordLength);
		int nRno = toBigEndian(nRecordNumber);
		shpFile.write(reinterpret_cast<char*>(&nRno), sizeof(int));
		shpFile.write(reinterpret_cast<char*>(&recordLength), sizeof(int));

		// д�뼸������--Ҫ������
		int shapeType = static_cast<int>(geom->getType());
		shpFile.write(reinterpret_cast<char*>(&shapeType), sizeof(int));
		// д��box��Χ
		double xmin = geom->getBoundBox()[0];
		double ymin = geom->getBoundBox()[1];
		double xmax = geom->getBoundBox()[2];
		double ymax = geom->getBoundBox()[3];
		shpFile.write(reinterpret_cast<char*>(&xmin), sizeof(double));
		shpFile.write(reinterpret_cast<char*>(&ymin), sizeof(double));
		shpFile.write(reinterpret_cast<char*>(&xmax), sizeof(double));
		shpFile.write(reinterpret_cast<char*>(&ymax), sizeof(double));
		// д��part��
		int nPartNum = geom->getPartSize();
		shpFile.write(reinterpret_cast<char*>(&nPartNum), sizeof(int));
		// д�����
		int nPointNum = geom->getPointSize();
		shpFile.write(reinterpret_cast<char*>(&nPointNum), sizeof(int));
		// д��part����
		for (int i = 0; i < nPartNum; i++) {
			int partIndex = geom->getParts()[i];
			shpFile.write(reinterpret_cast<char*>(&partIndex), sizeof(int));
		}
		// д�������
		for (int i = 0; i < nPointNum; i++) {
			double x = (*geom)[i]->x;
			double y = (*geom)[i]->y;
			shpFile.write(reinterpret_cast<char*>(&x), sizeof(double));
			shpFile.write(reinterpret_cast<char*>(&y), sizeof(double));
		}
		nRecordNumber++;
	}
}