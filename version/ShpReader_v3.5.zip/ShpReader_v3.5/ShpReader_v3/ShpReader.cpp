#include "ShpReader.h"

#include <fstream>
#include <iostream>

// ����shp�ļ�
Layer* ShpReader::ParseShpfile(std::string& sFilePath) {
	// �����ļ�ͷ
	int nFileLength = 0;				 // �ļ�����
	int nFeatureType = 0;			     // Ҫ������
	int nFeatureCount = 0;			     // Ҫ������
	double dvBound[BOUNDINGBOX_SIZE] = {}; // �߽��
	std::vector<Geometry*> geomList;	 // Ҫ�ؼ���

	ParseShxHeader(sFilePath, nFeatureType, nFeatureCount, dvBound); // �����ļ�ͷ
	nFileLength = ParseShpContent(sFilePath, nFeatureCount, geomList);			 // �����ļ�����
	return new Layer(sFilePath, geomList, nFeatureType, nFileLength, dvBound);	 // ����ͼ�����
}
// ����shx�ļ�ͷ
void ShpReader::ParseShxHeader(std::string& sFilePath, int& featureType, int& featureCount, double* boundingBox) {
	// ��ȡshx�ļ�ͷ
	std::string shxFilePath = sFilePath.substr(0, sFilePath.size() - 4) + ".shx"; // ��ȡ�����ļ�·��--shx�ļ�ͷ��shp�ļ�ͷ��ͬ
	std::ifstream shxFile(shxFilePath.c_str(), std::ios::binary);	// ��shx�ļ�
	if (!shxFile.is_open()) {
		return;
	}
	// ��ȡ�ļ���
	int nFileCode = 0;
	shxFile.read(reinterpret_cast<char*>(&nFileCode), sizeof(int));
	nFileCode = ReverseBytes(nFileCode);
	if (nFileCode != 9994) {
		return;
	}

	// �����¼����
	shxFile.seekg(24, std::ios::beg);
	int nFileLength;
	shxFile.read(reinterpret_cast<char*>(&nFileLength), sizeof(int));
	nFileLength = ReverseBytes(nFileLength);
	featureCount = (nFileLength * 2 - 100) / 8;

	// ��ȡ��״����
	shxFile.seekg(32, std::ios::beg);
	shxFile.read(reinterpret_cast<char*>(&featureType), sizeof(int));

	// ��ȡ�߽��
	shxFile.seekg(36, std::ios::beg);
	shxFile.read(reinterpret_cast<char*>(boundingBox), sizeof(double) * 4);
}
// ����shp�ļ�����
int ShpReader::ParseShpContent(std::string& sFilePath, int featureCount, std::vector<Geometry*>& geomList) {
	std::ifstream shpFile(sFilePath.c_str(), std::ios::binary);
	if (!shpFile.is_open()) {
		return 0;
	}
	// ��ȡ�ļ�����
	int nFileLength = 0;
	shpFile.seekg(24, std::ios::beg);
	shpFile.read(reinterpret_cast<char*>(&nFileLength), sizeof(int));
	nFileLength = ReverseBytes(nFileLength);
	
	// �����ļ�ͷ
	shpFile.seekg(100, std::ios::beg);
	// ��ȡ��¼
	ParseRecord(shpFile, featureCount, geomList);

	return nFileLength;
}
// ������¼
void ShpReader::ParseRecord(std::ifstream& shpFile, int featureCount, std::vector<Geometry*>& geomList) {
	// ��ȡÿ����¼
	for (int i = 0; i < featureCount; i++) {
		int nRecordNumber = 0, nContentLength = 0;	//��¼�����ţ�������¼����
		shpFile.read(reinterpret_cast<char*>(&nRecordNumber), sizeof(int));
		shpFile.read(reinterpret_cast<char*>(&nContentLength), sizeof(int));
		nRecordNumber = ReverseBytes(nRecordNumber);
		nContentLength = ReverseBytes(nContentLength);

		int nShapeType = 0;
		shpFile.read(reinterpret_cast<char*>(&nShapeType), sizeof(int));

		Geometry* geom;
		GeoType type = static_cast<GeoType>(nShapeType);
		switch (type) {
		case GeoType::POINT:
			ParsePoint(shpFile, nRecordNumber, geomList);
			break;
		case GeoType::POLYLINE:
			ParsePoly<mPolyLine>(shpFile, nRecordNumber, geomList);
			break;
		case GeoType::POLYGON:
			ParsePoly<mPolygon>(shpFile, nRecordNumber, geomList);
		default:
			break;
		}
	}
}
// ������
void ShpReader::ParsePoint(std::ifstream& shpFile, int nRecordNumber, std::vector<Geometry*>& geomList) {
	double x, y;
	shpFile.read(reinterpret_cast<char*>(&x), sizeof(double));
	shpFile.read(reinterpret_cast<char*>(&y), sizeof(double));
	Geometry* geom = new mPoint(nRecordNumber, x, y);
	geomList.emplace_back(geom);
}
// �����ߺ���
template<typename T>
void ShpReader::ParsePoly(std::ifstream& shpFile, int nRecordNumber, std::vector<Geometry*>& geomList) {
	int numParts, numPoints;
	double box[4];
	std::vector<int> parts;
	std::vector<PointXY*> points;

	for (int i = 0; i < 4; i++) {
		shpFile.read(reinterpret_cast<char*>(&box[i]), sizeof(double));
	}
	shpFile.read(reinterpret_cast<char*>(&numParts), sizeof(int));
	shpFile.read(reinterpret_cast<char*>(&numPoints), sizeof(int));

	parts.resize(numParts);
	for (int i = 0; i < numParts; i++) {
		shpFile.read(reinterpret_cast<char*>(&parts[i]), sizeof(int));
	}

	points.resize(numPoints);
	for (int i = 0; i < numPoints; i++) {
		double x, y;
		shpFile.read(reinterpret_cast<char*>(&x), sizeof(double));
		shpFile.read(reinterpret_cast<char*>(&y), sizeof(double));
		points[i] = new PointXY(x, y);
	}
	Geometry* geom = new T(nRecordNumber, box, parts, points);
	geomList.emplace_back(geom);
}