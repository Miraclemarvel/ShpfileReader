#include "ShpReader.h"
#include <iostream>

int main() {
	std::string sFilePath = "./data/soudpt.shp";
	
	ShpReader shp;
	Layer* layer1 = shp.ParseShpfile(sFilePath);
	Layer* layer(layer1);
	// ��ȡͼ����Ϣ
	std::cout << "layer name: " << layer->getName() << std::endl;
	std::cout << "number of features: " << layer->getSize() << std::endl;
	std::cout << "feature type: " << (layer->getType() == GeoType::POINT ? "POINT" : (layer->getType() == GeoType::POLYLINE ? "POLYLINE" : "POLYGON")) << std::endl;
	std::cout << "feature extent: " << layer->getBoundingBox()[0] << ", " << layer->getBoundingBox()[1] << ", " << layer->getBoundingBox()[2] << ", " << layer->getBoundingBox()[3] << std::endl;
	// ��ȡͼ��Ҫ���б�
	std::vector<Geometry*> features = layer->getFeatures();
	// ��������ֱ�ӻ�ȡͼ��Ҫ��
	for (int i = 0; i < layer->getSize(); i++) {
		std::cout << (*layer)[i]->getID() << std::endl;
		std::vector<PointXY*> ordinates = (*layer)[i]->getPoints();
		for (int j = 0; j < ordinates.size(); j++) {
			std::cout << ordinates[j]->x << ", " << ordinates[j]->y << " ";
		}
		std::cout << std::endl;
	}
	return 0;
}