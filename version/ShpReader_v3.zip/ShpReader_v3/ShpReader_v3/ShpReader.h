#pragma once
#include "Geometry.h"
#include "Layer.h"

#include<string>
constexpr int FILEHEADER_SIZE = 100;

class ShpReader{
public:
    ShpReader() {};
	// ����shp�ļ�
    Layer* ParseShpfile(std::string& sFilePath);

private:
	// �ֽ���ת������
	int ReverseBytes(int value) {
		return ((value & 0x000000FF) << 24) |
			((value & 0x0000FF00) << 8) |
			((value & 0x00FF0000) >> 8) |
			((value & 0xFF000000) >> 24);
	};
	// ����shx�ļ�ͷ
    void ParseShxHeader(std::string& sFilePath, int &featureType, int &featureCount, double* boundingBox);
	// ����shp�ļ�����
	void ParseShpContent(std::string& sFilePath, int featureCount, std::vector<Geometry*>& geomList);
	// ������¼
    void ParseRecord(std::ifstream &shpFile, int featureCount, std::vector<Geometry*>& geomList);
	// ������
    void ParsePoint(std::ifstream &shpFile, int nRecordNumber, std::vector<Geometry*>& geomList);
	// �����ߺ���
	template<typename T> 
	void ParsePoly(std::ifstream &shpFile, int nRecordNumber, std::vector<Geometry*>& geomList);
};

