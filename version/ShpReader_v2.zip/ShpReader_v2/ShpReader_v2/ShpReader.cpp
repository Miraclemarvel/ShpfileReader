#include "ShpReader.h"
#include <iostream>

// ���캯��
ShpReader::ShpReader(std::string filePath)
	: mFilePath(filePath)
{}

// ����shp�ļ�
std::vector<Geometry*> ShpReader::ParseShpFile() {
	// ��shp�ļ�
	std::ifstream shpFile(mFilePath, std::ios::binary);
	if (!shpFile.is_open()) {
		std::cerr << "Failed to open the shp file." << std::endl;
		return {};
	}

	// ��ȡshp�ļ�ͷ
	int fileCode;
	shpFile.read(reinterpret_cast<char*>(&fileCode), sizeof(int));
	fileCode = ReverseBytes(fileCode);
	if (fileCode != 9994) {
		std::cerr << "Invalid file code." << std::endl;
		return {};
	}

	// ������������5������
	int skip[5];
	shpFile.read(reinterpret_cast<char*>(skip), sizeof(int) * 5);

	// ��ȡ�ļ����ȺͰ汾��Ϣ
	int fileLength, version;
	shpFile.read(reinterpret_cast<char*>(&fileLength), sizeof(int));
	fileLength = ReverseBytes(fileLength);
	shpFile.read(reinterpret_cast<char*>(&version), sizeof(int));
	//version = ReverseBytes(version);

	// ��ȡ��״����
	int shapeType;
	shpFile.read(reinterpret_cast<char*>(&shapeType), sizeof(int));
	auto shpType = static_cast<GeoType>(shapeType);

	// ��ȡ�߽��
	double bounds[4];
	shpFile.read(reinterpret_cast<char*>(bounds), sizeof(double) * 4);

	// ��ȡz��m�ķ�Χ�������Ҫ��
	double zRange[2], mRange[2];
	shpFile.read(reinterpret_cast<char*>(zRange), sizeof(double) * 2);
	shpFile.read(reinterpret_cast<char*>(mRange), sizeof(double) * 2);

	// �����ȡ����Ϣ
	std::cout << "File Code: " << fileCode << std::endl;
	std::cout << "File Length: " << fileLength << std::endl;
	std::cout << "Version: " << version << std::endl;
	std::cout << "Shape Type: " << (shpType == GeoType::POINT ? "Point" : (shpType == GeoType::POLYLINE ? "PolyLine" : "Polygon")) << std::endl;
	std::cout << "Bounds: " << bounds[0] << ", " << bounds[1] << ", " << bounds[2] << ", " << bounds[3] << std::endl;

	std::vector<Geometry*> geometries;

	// ��ȡÿ����״�ļ�������
	while (!shpFile.eof()) {
		int recordNumber, contentLength;
		shpFile.read(reinterpret_cast<char*>(&recordNumber), sizeof(int));
		shpFile.read(reinterpret_cast<char*>(&contentLength), sizeof(int));
		recordNumber = ReverseBytes(recordNumber);
		contentLength = ReverseBytes(contentLength);
		//std::cout << "Record Number: " << recordNumber << ", Content Length: " << contentLength << std::endl;
		// ����shapeType��ȡ����ļ�������
		// ������Ҫ����shapeType��ֵ��������ζ�ȡ�ͽ�����������
		// ���磬���ڵ����ͣ�shapeType = 1������Ҫ��ȡx��y����
		// ����shapeType��ȡ����ļ�������
		switch (shpType) {
		case GeoType::POINT: // ��
			if (ReadPoint(shpFile, contentLength, geometries) != 0) {
				std::cerr << "Failed to read point." << std::endl;
			}
			break;
		case GeoType::POLYLINE: // ��
			if (ReadPolyLine(shpFile, contentLength, geometries) != 0) {
				std::cerr << "Failed to read polyline." << std::endl;
			}
			break;
		case GeoType::POLYGON: // ��
			if (ReadPolygon(shpFile, contentLength, geometries) != 0) {
				std::cerr << "Failed to read polygon." << std::endl;
			}
			break;
		default:
			std::cerr << "Unsupported shape type: " << shapeType << std::endl;
			break;
		}
	}
	shpFile.close();
	return geometries;
}


// ��ȡ��Ҫ��
int ShpReader::ReadPoint(std::ifstream& shpFile, int contentLength, std::vector<Geometry*>& points) {
	if (shpFile.eof()) {
		return -1;
	}
	int shapeType;
	double x, y;
	shpFile.read(reinterpret_cast<char*>(&shapeType), sizeof(int));
	shapeType = ReverseBytes(shapeType);
	shpFile.read(reinterpret_cast<char*>(&x), sizeof(double));
	shpFile.read(reinterpret_cast<char*>(&y), sizeof(double));
	points.emplace_back(new Point(x, y));
	return 0;
}

// ��ȡ��Ҫ��
int ShpReader::ReadPolyLine(std::ifstream& shpFile, int contentLength, std::vector<Geometry*>& lines) {
	if (shpFile.eof()) {
		return -1;
	}
	int shapeType, numParts, numPoints;
	double box[4];
	std::vector<int> parts;
	std::vector<Point> points;

	shpFile.read(reinterpret_cast<char*>(&shapeType), sizeof(int));
	for (int i = 0; i < 4; i++) {
		shpFile.read(reinterpret_cast<char*>(&box[i]), sizeof(double));
	}
	shpFile.read(reinterpret_cast<char*>(&numParts), sizeof(int));
	shpFile.read(reinterpret_cast<char*>(&numPoints), sizeof(int));

	parts.resize(numParts);
	for (int i = 0; i < numParts; i++) {
		shpFile.read(reinterpret_cast<char*>(&parts[i]), sizeof(int));
	}

	points.resize(numPoints);
	for (int i = 0; i < numPoints; i++) {
		double x = points[i].getX();
		double y = points[i].getY();
		shpFile.read(reinterpret_cast<char*>(&x), sizeof(double));
		shpFile.read(reinterpret_cast<char*>(&y), sizeof(double));
	}
	lines.emplace_back(new PolyLine(box, numParts, numPoints, parts, points));
	return 0;
}

// ��ȡ��Ҫ��
int ShpReader::ReadPolygon(std::ifstream& shpFile, int contentLength, std::vector<Geometry*>& polygons) {
	if (shpFile.eof()) {
		return -1;
	}
	int shapeType, numParts, numPoints;
	double box[4];
	std::vector<int> parts;
	std::vector<Point> points;

	shpFile.read(reinterpret_cast<char*>(&shapeType), sizeof(int));
	for (int i = 0; i < 4; i++) {
		shpFile.read(reinterpret_cast<char*>(&box[i]), sizeof(double));
	}
	shpFile.read(reinterpret_cast<char*>(&numParts), sizeof(int));
	shpFile.read(reinterpret_cast<char*>(&numPoints), sizeof(int));

	parts.resize(numParts);
	for (int i = 0; i < numParts; i++) {
		shpFile.read(reinterpret_cast<char*>(&parts[i]), sizeof(int));
	}

	points.resize(numPoints);
	for (int i = 0; i < numPoints; i++) {
		double x = points[i].getX();
		double y = points[i].getY();
		shpFile.read(reinterpret_cast<char*>(&x), sizeof(double));
		shpFile.read(reinterpret_cast<char*>(&y), sizeof(double));
	}
	polygons.emplace_back(new Polygon{ box, numParts, numPoints, parts, points });
	return 0;
}