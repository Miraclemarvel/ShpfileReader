#pragma once
#ifndef SHAPEFILE_READER_H
#define SHAPEFILE_READER_H

#include "Geometry.h"
#include <fstream>

class ShpReader{
public:
	// ���캯��
    ShpReader(std::string filePath);

	// ����shp�ļ�
	std::vector<Geometry*> ParseShpFile();

private:
	// �ֽ���ת������
    int ReverseBytes(int value) {
		return ((value & 0x000000FF) << 24) |
			((value & 0x0000FF00) << 8) |
			((value & 0x00FF0000) >> 8) |
			((value & 0xFF000000) >> 24);
    };

	// ��ȡ��Ҫ��
	int ReadPoint(std::ifstream& shpFile, int contentLength, std::vector<Geometry*>& points);

	// ��ȡ��Ҫ��
	int ReadPolyLine(std::ifstream& shpFile, int contentLength, std::vector<Geometry*>& lines);

	// ��ȡ��Ҫ��
	int ReadPolygon(std::ifstream& shpFile, int contentLength, std::vector<Geometry*>& polygons);

private:
    std::string mFilePath;       // �ļ�·��
};
#endif // SHAPEFILE_READER_H

