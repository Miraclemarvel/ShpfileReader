#include "ShpReader.h"
#include "ShpWriter.h"
#include <iostream>

int main() {
	std::string sFilePath = "./data/soudpt.shp";
	
	ShpReader shp;
	Layer* layer1 = shp.ParseShpfile(sFilePath);
	Layer* layer(layer1);
	// ��ȡͼ����Ϣ
	std::cout << "layer name: " << layer->getName() << std::endl;
	std::cout << "number of features: " << layer->getSize() << std::endl;
	std::cout << "feature type: " << (layer->getType() == GeoType::POINT ? "POINT" : (layer->getType() == GeoType::POLYLINE ? "POLYLINE" : "POLYGON")) << std::endl;
	std::cout << "feature extent: " << layer->getBoundingBox()[0] << ", " << layer->getBoundingBox()[1] << ", " << layer->getBoundingBox()[2] << ", " << layer->getBoundingBox()[3] << std::endl;
	std::cout << "Attributes Names: ";
	auto ret = layer->getFields();
	for (auto field : ret) {
		std::cout << field.name << "\t ";
	}
	std::cout << std::endl;
	std::cout << "Attributes Values: " << std::endl;
	std::string name = "SOUDPT_ID";
	std::cout << "\tSOUDPT_ID: " << std::endl;
	for (int i = 0; i < layer->getSize(); i++) {
		/*for (int j = 0; j < layer->getFields().size(); j++) {
			std::cout << (*layer)[i]->getAttributes()[j] << " ";
		}
		std::cout << std::endl;*/
		
		std::cout << layer->getFeatureByID(i)->getAttributeByName(name) << std::endl;
	}
	
	// ��ȡͼ��Ҫ���б�
	//std::vector<Geometry*> features = layer->getFeatures();
	// ��������ֱ�ӻ�ȡͼ��Ҫ��
	//for (int i = 0; i < layer->getSize(); i++) {
	//	std::cout << (*layer)[i]->getID() << std::endl;
	//	std::vector<PointXY*> ordinates = (*layer)[i]->getPoints();
	//	for (int j = 0; j < ordinates.size(); j++) {
	//		std::cout << ordinates[j]->x << ", " << ordinates[j]->y << " ";
	//	}
	//	std::cout << std::endl;
	//}
	/*std::string sOutFilePath = "./data/result/polygon.shp";
	ShpWriter writer(sOutFilePath);
	writer.ParseLayer(layer);
	std::cout << "write to" << sOutFilePath << " successfully" << std::endl;*/
	return 0;
}