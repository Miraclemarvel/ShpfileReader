#include "mPoint.h"

// ���캯��
mPoint::mPoint(int id, double x, double y) : Geometry(id) {
	double bound[BOUNDINGBOX_SIZE];
	bound[0] = x;
	bound[1] = y;
	bound[2] = x;
	bound[3] = y;
	this->setBoundBox(bound);

	this->setParts({ 0 });

	this->setPoints({ new PointXY(x, y) });
}