#include "ShpReader.h"

#include <fstream>
#include <iostream>


// ����shp�ļ�
Layer* ShpReader::ParseShpfile(std::string& sFilePath) {
	// �����ļ�ͷ
	int nFileLength = 0;				 // �ļ�����
	int nFeatureType = 0;			     // Ҫ������
	int nFeatureCount = 0;			     // Ҫ������
	double dvBound[BOUNDINGBOX_SIZE] = {}; // �߽��
	std::vector<Geometry*> geomList;	 // Ҫ�ؼ���
	DBFHeader header;				     // dbf�ļ�ͷ
	fieldList fields;				     // �ֶ��б�

	ParseShxHeader(sFilePath, nFeatureType, nFeatureCount, dvBound);             // �����ļ�ͷ
	nFileLength = ParseShpContent(sFilePath, nFeatureCount, geomList);			 // �����ļ�����
	ParseDbfFile(sFilePath, nFeatureCount, geomList, header, fields);                // ����dbf�ļ�
	return new Layer(sFilePath, geomList, nFeatureType, nFileLength, dvBound, header, fields);	 // ����ͼ�����
}
// ����shx�ļ�ͷ
void ShpReader::ParseShxHeader(std::string& sFilePath, int& featureType, int& featureCount, double* boundingBox) {
	// ��ȡshx�ļ�ͷ
	std::string shxFilePath = sFilePath.substr(0, sFilePath.size() - 4) + ".shx"; // ��ȡ�����ļ�·��--shx�ļ�ͷ��shp�ļ�ͷ��ͬ
	std::ifstream shxFile(shxFilePath.c_str(), std::ios::binary);	// ��shx�ļ�
	if (!shxFile.is_open()) {
		return;
	}
	// ��ȡ�ļ���
	int nFileCode = 0;
	shxFile.read(reinterpret_cast<char*>(&nFileCode), sizeof(int));
	nFileCode = ReverseBytes(nFileCode);
	if (nFileCode != 9994) {
		return;
	}

	// �����¼����
	shxFile.seekg(24, std::ios::beg);
	int nFileLength;
	shxFile.read(reinterpret_cast<char*>(&nFileLength), sizeof(int));
	nFileLength = ReverseBytes(nFileLength);
	featureCount = (nFileLength * 2 - 100) / 8;

	// ��ȡ��״����
	shxFile.seekg(32, std::ios::beg);
	shxFile.read(reinterpret_cast<char*>(&featureType), sizeof(int));

	// ��ȡ�߽��
	shxFile.seekg(36, std::ios::beg);
	shxFile.read(reinterpret_cast<char*>(boundingBox), sizeof(double) * 4);
}
// ����shp�ļ�����
int ShpReader::ParseShpContent(std::string& sFilePath, int featureCount, std::vector<Geometry*>& geomList) {
	std::ifstream shpFile(sFilePath.c_str(), std::ios::binary);
	if (!shpFile.is_open()) {
		return 0;
	}
	// ��ȡ�ļ�����
	int nFileLength = 0;
	shpFile.seekg(24, std::ios::beg);
	shpFile.read(reinterpret_cast<char*>(&nFileLength), sizeof(int));
	nFileLength = ReverseBytes(nFileLength);
	
	// �����ļ�ͷ
	shpFile.seekg(100, std::ios::beg);
	// ��ȡ��¼
	ParseRecord(shpFile, featureCount, geomList);

	return nFileLength;
}
// ����dbf�ļ�
void ShpReader::ParseDbfFile(std::string& sFilePath, int featureCount, std::vector<Geometry*>& geomList, DBFHeader& header, fieldList& fields) {
	// ��ȡdbf�ļ�ͷ
	std::string dbfFilePath = sFilePath.substr(0, sFilePath.size() - 4) + ".dbf";
	std::ifstream dbfFile(dbfFilePath.c_str(), std::ios::binary);	// ��dbf�ļ�
	header = parseDBFHeader(dbfFile);
	// ��ȡ�ֶ�������
	parseFieldDescriptors(dbfFile, header.headerLength, fields);
	// ��ȡ��¼
	dbfFile.seekg(header.headerLength, std::ios::beg);
	for (int i = 0; i < featureCount; i++) {
		Geometry* geom = geomList[i];
		Attributes* attrs = new Attributes(dbfFile, header, fields);
		geom->setAttributes(attrs);
	}
}

// ������¼
void ShpReader::ParseRecord(std::ifstream& shpFile, int featureCount, std::vector<Geometry*>& geomList) {
	// ��ȡÿ����¼
	for (int i = 0; i < featureCount; i++) {
		int nRecordNumber = 0, nContentLength = 0;	//��¼�����ţ�������¼����
		shpFile.read(reinterpret_cast<char*>(&nRecordNumber), sizeof(int));
		shpFile.read(reinterpret_cast<char*>(&nContentLength), sizeof(int));
		nRecordNumber = ReverseBytes(nRecordNumber);
		nContentLength = ReverseBytes(nContentLength);

		int nShapeType = 0;
		shpFile.read(reinterpret_cast<char*>(&nShapeType), sizeof(int));

		Geometry* geom;
		GeoType type = static_cast<GeoType>(nShapeType);
		switch (type) {
		case GeoType::POINT:
			ParsePoint(shpFile, nRecordNumber, geomList);
			break;
		case GeoType::POLYLINE:
			ParsePoly<mPolyLine>(shpFile, nRecordNumber, geomList);
			break;
		case GeoType::POLYGON:
			ParsePoly<mPolygon>(shpFile, nRecordNumber, geomList);
		default:
			break;
		}
	}
}
// ������
void ShpReader::ParsePoint(std::ifstream& shpFile, int nRecordNumber, std::vector<Geometry*>& geomList) {
	double x, y;
	shpFile.read(reinterpret_cast<char*>(&x), sizeof(double));
	shpFile.read(reinterpret_cast<char*>(&y), sizeof(double));
	Geometry* geom = new mPoint(nRecordNumber, x, y);
	geomList.emplace_back(geom);
}
// �����ߺ���
template<typename T>
void ShpReader::ParsePoly(std::ifstream& shpFile, int nRecordNumber, std::vector<Geometry*>& geomList) {
	int numParts, numPoints;
	double box[4];
	std::vector<int> parts;
	std::vector<PointXY*> points;

	for (int i = 0; i < 4; i++) {
		shpFile.read(reinterpret_cast<char*>(&box[i]), sizeof(double));
	}
	shpFile.read(reinterpret_cast<char*>(&numParts), sizeof(int));
	shpFile.read(reinterpret_cast<char*>(&numPoints), sizeof(int));

	parts.resize(numParts);
	for (int i = 0; i < numParts; i++) {
		shpFile.read(reinterpret_cast<char*>(&parts[i]), sizeof(int));
	}

	points.resize(numPoints);
	for (int i = 0; i < numPoints; i++) {
		double x, y;
		shpFile.read(reinterpret_cast<char*>(&x), sizeof(double));
		shpFile.read(reinterpret_cast<char*>(&y), sizeof(double));
		points[i] = new PointXY(x, y);
	}
	Geometry* geom = new T(nRecordNumber, box, parts, points);
	geomList.emplace_back(geom);
}
// ����DBF�ļ�ͷ
DBFHeader ShpReader::parseDBFHeader(std::ifstream& file) {
	DBFHeader header;
	// ��ȡdbf�ļ�ͷ
	file.read(reinterpret_cast<char*>(&header.fileType), 1);
	file.read(reinterpret_cast<char*>(&header.year), 1);
	file.read(reinterpret_cast<char*>(&header.month), 1);
	file.read(reinterpret_cast<char*>(&header.day), 1);
	file.read(reinterpret_cast<char*>(&header.recordCount), 4);
	file.read(reinterpret_cast<char*>(&header.headerLength), 2);
	file.read(reinterpret_cast<char*>(&header.recordLength), 2);
	file.read(reinterpret_cast<char*>(&header.reserved1), 2);
	file.read(reinterpret_cast<char*>(&header.unFinished), 1);
	file.read(reinterpret_cast<char*>(&header.codeFlag), 1);
	file.read(reinterpret_cast<char*>(&header.reserved2), 12);
	file.read(reinterpret_cast<char*>(&header.MXDFlag), 1);
	file.read(reinterpret_cast<char*>(&header.LangDrivId), 1);
	file.read(reinterpret_cast<char*>(&header.reserved3), 2);
	return header;
}
// �����ֶ�������
void ShpReader::parseFieldDescriptors(std::ifstream& file, uint16_t headerLength, fieldList& fields) {
	while (file.tellg() < headerLength - 1) {
		char buffer[FIELDLENGTH];
		file.read(buffer, FIELDLENGTH);

		if (buffer[0] == 0x0D) break; // ������

		FieldDescriptor field;
		field.name = std::string(buffer, buffer + 11);
		//field.name.erase(field.name.find('\0')); // ȥ��β�����ַ�
		field.type = buffer[11];
		field.reserved1 = static_cast<uint32_t>(buffer[12]) << 24 | static_cast<uint32_t>(buffer[13]) << 16 | static_cast<uint32_t>(buffer[14]) << 8 | static_cast<uint32_t>(buffer[15]);
		field.length = static_cast<uint8_t>(buffer[16]);
		field.decimalCount = static_cast<uint8_t>(buffer[17]);
		field.reserved2 = static_cast<uint16_t>(buffer[18]) << 8 | static_cast<uint16_t>(buffer[19]);
		field.workAreaID = static_cast<uint8_t>(buffer[20]);
		field.reserved3 = std::string(buffer + 21, buffer + 31);	
		field.MDXFlag = static_cast<uint8_t>(buffer[31]);
		fields.push_back(field);
	}
}